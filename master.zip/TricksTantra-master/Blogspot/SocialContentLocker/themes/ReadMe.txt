Photo Name is theme name
